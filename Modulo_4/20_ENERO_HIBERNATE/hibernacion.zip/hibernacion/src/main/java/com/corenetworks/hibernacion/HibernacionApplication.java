package com.corenetworks.hibernacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernacionApplication.class, args);
	}

}
