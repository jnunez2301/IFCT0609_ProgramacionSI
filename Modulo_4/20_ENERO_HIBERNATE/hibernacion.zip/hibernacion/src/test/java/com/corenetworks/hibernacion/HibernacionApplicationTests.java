package com.corenetworks.hibernacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
