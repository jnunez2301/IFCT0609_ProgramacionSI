package com.corenetworks.validcaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidcacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
