package com.corenetworks.validcaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidcacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidcacionesApplication.class, args);
	}

}
