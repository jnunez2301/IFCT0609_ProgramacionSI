package com.corenetworks.madurezRestFull.repositorio;

import com.corenetworks.madurezRestFull.modelo.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IPacienteRepositorio extends IGenericoRepositorio<Paciente,Integer> {
}
