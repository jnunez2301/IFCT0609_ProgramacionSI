package com.corenetworks.madurezRestFull.servicio;

import com.corenetworks.madurezRestFull.modelo.Paciente;

import java.util.List;

public interface IPacienteServicio extends ICRUD<Paciente,Integer>{

}
