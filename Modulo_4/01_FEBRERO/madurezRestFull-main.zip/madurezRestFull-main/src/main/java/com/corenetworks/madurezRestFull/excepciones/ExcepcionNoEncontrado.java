package com.corenetworks.madurezRestFull.excepciones;

public class ExcepcionNoEncontrado extends RuntimeException{
    public ExcepcionNoEncontrado(String message) {
        super(message);
    }
}
