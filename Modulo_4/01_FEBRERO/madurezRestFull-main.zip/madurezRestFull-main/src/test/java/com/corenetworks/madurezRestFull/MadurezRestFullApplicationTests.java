package com.corenetworks.madurezRestFull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadurezRestFullApplicationTests {

	@Test
	void contextLoads() {
	}

}
