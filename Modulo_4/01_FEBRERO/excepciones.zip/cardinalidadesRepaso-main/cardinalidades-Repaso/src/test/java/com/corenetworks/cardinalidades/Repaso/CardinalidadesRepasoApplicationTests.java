package com.corenetworks.cardinalidades.Repaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardinalidadesRepasoApplicationTests {

	@Test
	void contextLoads() {
	}

}
