package com.corenetworks.cardinalidades.Repaso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardinalidadesRepasoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardinalidadesRepasoApplication.class, args);
	}

}
