package com.corenetworks.cardinalidades.Repaso.excepciones;

public class ExcepcionNoEncontradoModelo extends RuntimeException{
    public ExcepcionNoEncontradoModelo(String message) {
        super(message);
    }
}
